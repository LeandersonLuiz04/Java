public abstract class Pessoa {
    public String nome;
    public int idade;
    public String telefone;
    public String endereco;
    public int id;

    public Pessoa(String n, int i, String t){
        this.nome=n;
        this.idade=i;
        this.telefone=t;
    }
    public abstract void listarDados();



}
