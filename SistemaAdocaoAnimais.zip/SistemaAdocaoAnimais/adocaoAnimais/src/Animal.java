public abstract class Animal {
    public String nome;
    public int idade;
    public int id;
    public String origem;
    public boolean sociavel;
    public String especificacoes;


    public Animal(String n, int i,String o,String e){
        this.nome=n;
        this.idade=i;
        this.origem=o;
        this.especificacoes=e;
    }
    public abstract void listarDados();




}
