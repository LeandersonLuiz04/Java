package com.poo.avaliacao;

import java.util.ArrayList;

public abstract class Visitante {
    protected String name;
    protected String identificador;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getIdentificador() {
        return identificador;
    }

    public void setIdentificador(String identificador) {
        this.identificador = identificador;
    }

    public abstract void registrarEntrada();

    public abstract void registrarSaida();

    public abstract void consultar();
}
