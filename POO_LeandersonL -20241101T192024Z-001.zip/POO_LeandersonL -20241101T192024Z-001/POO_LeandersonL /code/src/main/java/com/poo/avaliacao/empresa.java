package com.poo.avaliacao;

import java.util.ArrayList;

public class empresa extends Visitante {
    static ArrayList<String> nomeEmpresa = new ArrayList<>();
    static ArrayList<String> idEmpresa = new ArrayList<>();

    @Override
    public void registrarEntrada() {
        nomeEmpresa.add(name);
        idEmpresa.add(identificador);
        System.out.println("NOME: " + name);
        System.out.println("ID: " + identificador);
    }

    @Override
    public void registrarSaida() {
        nomeEmpresa.remove(name);
        idEmpresa.remove(identificador);
    }

    @Override
    public void consultar() {
        System.out.println("EMPRESAS CADASTRADAS: " + nomeEmpresa.size());
        for (int i = 0; i < nomeEmpresa.size(); i++) {
            System.out.println("EMPRESA: " + nomeEmpresa.get(i) + " ID: " + idEmpresa.get(i));
        }
    }
}
