package com.poo.avaliacao;

import java.io.IOException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws IOException {
        Scanner reader = new Scanner(System.in);
        
        while (true) { 

            System.out.println("-------PREDIO XYZ--------");
            System.out.println("O que você deseja fazer? :");
            System.out.println("1-Registrar entrada de visitante.");
            System.out.println("2-Registrar saída de visitante.");
            System.out.println("3-Consultar visitantes no prédio.");
            System.out.println("4-Consultar visitantes(todos).");
            System.out.println("5-Sair.");

            int n = reader.nextInt();
            reader.nextLine();
            
            switch (n) {
                case 1: 
                    System.out.println("Você deseja fazer cadastro de pessoa física ou cadastrar uma empresa?");
                    System.out.print("Digite P para PESSOA FÍSICA ou digite E para EMPRESA: ");
                    String choice = reader.nextLine().toLowerCase();

                    if (choice.equals("p")) {
                        Pessoa pessoa = new Pessoa();
                        System.out.print("Nome do Visitante: ");
                        pessoa.setName(reader.nextLine());
                        pessoa.setIdentificador(String.valueOf(Math.random()));
                        pessoa.registrarEntrada();
                    }
                     else if (choice.equals("e")) {

                        empresa Empresa = new empresa();
                        System.out.print("Nome da Empresa: ");
                        Empresa.setName(reader.nextLine());
                        Empresa.setIdentificador(String.valueOf(Math.random()));
                        Empresa.registrarEntrada();
                    } 
                    else {
                        System.out.println("ERRO.");
                    }
                    break;

                case 2:
                    System.out.println("Quem deseja sair é uma PESSOA FÍSICA ou uma EMPRESA?");
                    System.out.print("Digite p para PESSOA FÍSICA ou e para EMPRESA: ");
                    String choice2 = reader.nextLine().toLowerCase();

                    if (choice2.equals("p")) {
                        Pessoa pessoa = new Pessoa();
                        System.out.print("Nome da pessoa que deseja sair: ");
                        pessoa.setName(reader.nextLine());
                        System.out.print("ID: ");
                        pessoa.setIdentificador(reader.nextLine());
                        pessoa.registrarSaida();

                    } 
                    else if (choice2.equals("e")) {
                        empresa Empresa = new empresa();
                        System.out.print("Nome da Empresa que deseja sair: ");
                        Empresa.setName(reader.nextLine());
                        System.out.print("ID: ");
                        Empresa.setIdentificador(reader.nextLine());
                        Empresa.registrarSaida();
                    } 
                    else {
                        System.out.println("ERRO");
                    }
                    break;

                case 3:
                    System.out.println("Você deseja consultar PESSOAS FÍSICAS ou EMPRESAS?");
                    System.out.print("Digite p para PESSOAS FÍSICAS ou e para EMPRESAS: ");
                    String choice3 = reader.nextLine().toLowerCase();

                    if (choice3.equals("p")) {
                        Pessoa pessoa = new Pessoa();
                        pessoa.consultar();

                    } 
                    else if (choice3.equals("e")) {
                        empresa Empresa = new empresa();
                        Empresa.consultar();
                    } 

                    else {
                        System.out.println("ERRO.");
                    }
                    break;

                case 4:
                    System.out.println("---------PESSOAS FÍSICAS-------------");
                    new Pessoa().consultar();
                    System.out.println("------------------------------");
                    System.out.println("");

                    System.out.println("-----------EMPRESAS-------------");
                    new empresa().consultar();
                    System.out.println("-----------------------------");
                    
                    break;

                case 5:
                    System.out.println("Sistema desligado.");
                    reader.close();
                    return;
            }
        }
    }
}
