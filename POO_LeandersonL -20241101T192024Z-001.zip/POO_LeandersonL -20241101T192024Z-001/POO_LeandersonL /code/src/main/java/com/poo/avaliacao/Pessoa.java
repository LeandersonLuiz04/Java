package com.poo.avaliacao;

import java.util.ArrayList;

public class Pessoa extends Visitante {
    static ArrayList<String> pessoasFisicas = new ArrayList<>();
    static ArrayList<String> idPessoas = new ArrayList<>();

    @Override
    public void registrarEntrada() {
        pessoasFisicas.add(name);
        idPessoas.add(identificador);
        System.out.println("NOME: " + name);
        System.out.println("ID: " + identificador);
    }

    @Override
    public void registrarSaida() {
        pessoasFisicas.remove(name);
        idPessoas.remove(identificador);
    }

    @Override
    public void consultar() {
        System.out.println("PESSOAS QUE POSSUEM O CRACHÁ: " + pessoasFisicas.size());
        for (int i = 0; i < pessoasFisicas.size(); i++) {
            System.out.println("PESSOA: " + pessoasFisicas.get(i) + " ID: " + idPessoas.get(i));
        }
    }
}
